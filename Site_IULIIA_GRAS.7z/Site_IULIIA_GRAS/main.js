let btnFilm = document.getElementById("film");


btnFilm.addEventListener('mouseover', Click1);

function Click1(){
    this.textContent = "Après une serie de meurtres dans une petite ville Australienne, la police panique";
}

btnFilm.removeEventListener('mouseout', Click1);
