<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link href="CSS/reset.css" rel="stylesheet" type="text/css">
<link href="CSS/style.css" rel="stylesheet" type="text/css">
</head>
 <body>
<header>

<div id="gauche"> <img src="Images/logo_cine_toile.png" title="logo" alt="logo"> </div>
<div id="milieu">
  <div id="milieutitre">
  <h2>Recherchez un film</h2>
  </div>
</div>
<div id="droite">
    <div id="titrereseaux">
      <a href="http://www.instagram.com" target="_blank"> <img src="Images/instagram_logo.png" title="instagram" alt="facebook"></a>
      <a href="http://www.facebook.com" target="_blank"> <img src="Images/facebook_logo.png" title="facebook" alt="facebook"></a>
    </div>
     <div id="iconesreseaux"><img src="Images/popcorn.png" title="logo" alt="logo"></div>
</div>
</header>
<nav>
    <a href="index1.html" target="_parent">ACCUEIL</a>
  <div class="separateur"></div>
  <a href="index2.html" target="_parent">FILMS</a>
  <div class="separateur"></div>
  <a href="#"target="_parent">CINEMA</a>
  <div class="separateur"></div>
  <a href="#"target="_parent">OFFRES</a>
  <div class="separateur"></div>
  <a href="#"target="_parent">RESERVATIONS</a>
</nav>
<div id="content">
<div id="side">
  <div id="sidetop"> <p class="affiche">A L'AFFICHE</p></div>
   <div id="sidemil"> <img src="Images/le bon.jpg" title="bon" alt="bon"></div>
    <div id="sidebot"><img src="Images/indochine.jpg" title="indochine" alt="indochine"></div>
</div>
 <div id="container1"> 
   <?php
   $user="root";
   $mdp="";
   $server="localhost";
   $bdd ="MONCINEMA";
    $connexion = new mysqli($server,$user,$mdp,$bdd) or die(mysqli_connect_error());
	$sqlFilm = "SELECT * FROM Film";
	$resultFilm = $connexion->query($sqlFilm) or die($connexion->error);
	$nbFilms = $resultFilm->num_rows;
	if($nbFilms > 0){
	while($film = $resultFilm->fetch_array()){
	?>
    <div id="film"><img src="<?php echo $film["image"]; ?>" title="indochine" alt="indochine">
    <div><p class="titre"><?php echo $film["titre"]; ?></p></div>
    </div>
    <div id="film"><img src="<?php echo $film["image"]; ?>" title="indochine" alt="indochine">
     <div><p class="titre"><?php echo $film["titre"]; ?></p></div>
    </div>
    <div id="film"><img src="<?php echo $film["image"]; ?>" title="indochine" alt="indochine">
    <div><p class="titre"><?php echo $film["titre"]; ?></p></div>
    </div>
    <div id="film"><img src="<?php echo $film["image"]; ?>" title="indochine" alt="indochine">
    <div><p class="titre"><?php echo $film["titre"]; ?></p></div>   </div>
    <?php
								}
							}
							else{
								echo "<div id=\"film\">";
								echo "<h2>Aucun film trouvé</h2>";
								echo "</div>";
							}
						?>
   </div>
 </div> 

<footer>
<div id="gauchefooter"></div>
  
  <div id="milieufooter">
    <img src="Images/logo_cine_toile.png">
  </div>
    <div id="droitefooter"></div>
  
  </div>
 </footer>
 <script src="main.js"></script>
 </body>
</html>